import { node, empty, reverseList } from "../include/lists.js";
export function keepTrendMiddles(lst, allSatisfy) {
    if (lst.isEmpty() || lst.tail().isEmpty() || lst.tail().tail().isEmpty()) {
        return empty();
    }
    else if (allSatisfy(lst.head(), lst.tail().head(), lst.tail().tail().head())) {
        return node(lst.tail().head(), keepTrendMiddles(lst.tail(), allSatisfy));
    }
    else {
        return keepTrendMiddles(lst.tail(), allSatisfy);
    }
}
export function keepLocalMaxima(lst) {
    return keepTrendMiddles(lst, (p, c, n) => c > p && c > n);
}
export function keepLocalMinima(lst) {
    return keepTrendMiddles(lst, (p, c, n) => c < p && c < n);
}
export function keepLocalMinimaAndMaxima(lst) {
    return keepTrendMiddles(lst, (p, c, n) => (c < p && c < n) || (c > p && c > n));
}
export function invalidN(n) {
    return n <= 0 || !Number.isInteger(n);
}
export function everyNList(lst, n) {
    // TODO: Implement this function
    const revlst = reverseList(lst);
    return everyNRev(revlst, n);
}
export function everyNRev(lst, n) {
    // TODO: Implement this function;
    if (invalidN(n))
        return empty();
    let i = 1;
    const revlst = lst.reduce((acc, e) => node(e, acc), empty());
    const reducedlst = revlst.reduce((acc, e) => {
        if (i++ === n) {
            i = 1;
            acc = node(e, acc);
        }
        return acc;
    }, empty());
    return reducedlst.reduce((acc, e) => node(e, acc), empty());
}
export function everyNCond(lst, n, cond) {
    // TODO: Implement this function
    if (invalidN(n))
        return empty();
    let i = 0;
    return lst.filter((e) => {
        const nthElement = ++i % n === 0;
        return cond(e) && nthElement;
    });
}
export function productsHelper(lst, cond) {
    let prev = 1;
    const newlst = lst.reduce((acc, e) => {
        acc = cond(e) ? node(e * prev, acc) : acc;
        prev = cond(e) ? e * prev : 1;
        return acc;
    }, empty());
    return reverseList(newlst);
}
export function nonNegativeProducts(lst) {
    // TODO: Implement this function
    return productsHelper(lst, (n) => n >= 0);
}
export function negativeProducts(lst) {
    // TODO: Implement this function
    return productsHelper(lst, (n) => n < 0);
}
export function listSum(lst) {
    return lst.isEmpty() ? 0 : lst.head() + listSum(lst.tail());
}
export function squashList(lst) {
    // TODO: Implement this function
    return lst.map(e => (typeof e === "number" ? e : listSum(e)));
}
export function composeList(lst) {
    // TODO: Implement this function
    return (n) => lst.reduce((acc, f) => f(acc), n);
}
export function composeFunctions(funcArr) {
    // TODO: Implement this function
    return (a) => (x) => funcArr.reduce((acc, f) => f(acc, a), x);
}
//# sourceMappingURL=lists.js.map