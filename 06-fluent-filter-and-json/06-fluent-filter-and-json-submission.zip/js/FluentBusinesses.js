export class FluentBusinesses {
    data;
    constructor(data) {
        this.data = data;
    }
    getData() {
        return this.data;
    }
    hasProperty(business, key) {
        return business[key] !== undefined;
    }
    newFilteredFluentBusiness(cond) {
        const filtered = this.data.filter(cond);
        return new FluentBusinesses(filtered);
    }
    fromCityInState(city, state) {
        const cond = (b) => this.hasProperty(b, "city") &&
            this.hasProperty(b, "state") &&
            b.city !== undefined &&
            b.state !== undefined &&
            b.city === city &&
            b.state === state;
        return this.newFilteredFluentBusiness(cond);
    }
    hasStarsGeq(stars) {
        // TODO
        const cond = (b) => this.hasProperty(b, "stars") && b.stars !== undefined && b.stars >= stars;
        return this.newFilteredFluentBusiness(cond);
    }
    inCategory(category) {
        // TODO
        const cond = (b) => this.hasProperty(b, "categories") && b.categories !== undefined && b.categories.includes(category);
        return this.newFilteredFluentBusiness(cond);
    }
    hasHoursOnDays(days) {
        // TODO
        const cond = (b) => this.hasProperty(b, "hours") && days.length > 0 && days.every(day => b.hours !== undefined && day in b.hours);
        return this.newFilteredFluentBusiness(cond);
    }
    hasAmbience(ambience) {
        // TODO
        const cond = (b) => this.hasProperty(b, "attributes") &&
            b.attributes !== undefined &&
            b.attributes[ambience] !== undefined &&
            b.attributes[ambience] === true;
        return this.newFilteredFluentBusiness(cond);
    }
    bestPlaceAndmostReviewsHelper(str) {
        const property = str === "s" ? "stars" : "review_count";
        const filtered = this.data.filter(b => this.hasProperty(b, property));
        if (filtered.length === 0) {
            return undefined;
        }
        return filtered.reduce((acc, e) => {
            const currStars = acc.stars ?? 0;
            const currRevCnt = acc.review_count ?? 0;
            const newStars = e.stars ?? 0;
            const newRevCnt = e.review_count ?? 0;
            if (str === "s") {
                return newStars > currStars || (newStars === currStars && newRevCnt > currRevCnt) ? e : acc;
            }
            else {
                return newRevCnt > currRevCnt || (newRevCnt === currRevCnt && newStars > currStars) ? e : acc;
            }
        });
    }
    bestPlace() {
        // TODO
        return this.bestPlaceAndmostReviewsHelper("s");
    }
    mostReviews() {
        // TODO
        return this.bestPlaceAndmostReviewsHelper("r");
    }
}
//# sourceMappingURL=FluentBusinesses.js.map